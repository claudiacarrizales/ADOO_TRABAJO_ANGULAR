export const products = [
  {
    name: 'Phone XL',
    price: 799,
    description: 'A large phone with one of the best screens'
  },
  {
    name: 'Phone Mini',
    price: 699,
    description: 'A great phone with one of the best cameras'
  },
  {
    name: 'Phone Standard',
    price: 299,
    description: ''
  },
  {
    name: 'Computer',
    price: 5900,
    description: 'color roja, marca acer'
  },
  {
    name: 'Televisión',
    price: 12600,
    description: 'marca samsung'
  },
  {
    name: 'ipad',
    price: 16000,
    description: 'color blanca'
  },
  {
    name: 'Refrigerador',
    price: 15000,
    description: 'marca lg'
  },
  {
    name: 'Reloj',
    price: 1200,
    description: 'marca casio, color dorado'
  },
  {
    name: 'Mouse',
    price: 300,
    description: 'marca eagle warrior'
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/